package cat.itacademy.barcelonactiva.galan.carlos.s04.t02.n01.S04T02N01GalanCarlos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T02N01GalanCarlosApplicationTests {

	@Test
	void contextLoads() {
	}

}

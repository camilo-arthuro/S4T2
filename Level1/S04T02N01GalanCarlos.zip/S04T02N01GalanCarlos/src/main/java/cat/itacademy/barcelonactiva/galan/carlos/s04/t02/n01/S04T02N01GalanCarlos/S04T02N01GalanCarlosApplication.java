package cat.itacademy.barcelonactiva.galan.carlos.s04.t02.n01.S04T02N01GalanCarlos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T02N01GalanCarlosApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T02N01GalanCarlosApplication.class, args);
	}

}

package cat.itacademy.barcelonactiva.galan.carlos.s04.t02.n02.S04T02N02GalanCarlos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T02N02GalanCarlosApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T02N02GalanCarlosApplication.class, args);
	}

}
